class LoginPage
{

    constructor(page)
    {

        this.page=page
        this.username="#email1"
        this.password="//input[@id='password1']"
        this.loginbtn="//button[text()='Sign in']"
    }

    async loginToApplication()
    {
        
        await this.page.fill(this.username,"admin@gmail.com")
        await this.page.fill(this.password,"admin123")
        await this.page.click(this.loginbtn)
    }
}

module.exports=LoginPage;